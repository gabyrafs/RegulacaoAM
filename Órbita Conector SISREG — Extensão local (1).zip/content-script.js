const VERSAO_ADAPTADOR = "sisreg-3.4-observacional-0.1";

const REGRAS = [
  ["codigoSolicitacao", /c[oó]d(?:igo)?\.?\s*(?:da\s*)?solicita[cç][aã]o/i],
  ["cnesSolicitante", /cnes\s*solicitante/i],
  ["cnesExecutante", /cnes\s*executante/i],
  ["codigoUnificado", /c[oó]digo\s*unificado/i],
  ["codigoInterno", /c[oó]digo\s*interno/i],
  ["descricaoProcedimento", /descri[cç][aã]o(?:\s*do)?\s*procedimento/i],
  ["cid", /(?:^|\s)cid(?:-?10)?(?:\s|$)/i],
  ["classificacaoRisco", /classifica[cç][aã]o\s*(?:de)?\s*risco/i],
  ["situacao", /situa[cç][aã]o|status\s*(?:da)?\s*solicita[cç][aã]o/i],
  ["dataSolicitacao", /data\s*(?:da)?\s*solicita[cç][aã]o/i],
  ["avSemOD", /a(?:cuidade)?\.?\s*v(?:isual)?\.?.*od.*sem\s*corre[cç][aã]o/i],
  ["avSemOE", /a(?:cuidade)?\.?\s*v(?:isual)?\.?.*oe.*sem\s*corre[cç][aã]o/i],
  ["avComOD", /a(?:cuidade)?\.?\s*v(?:isual)?\.?.*od.*com\s*corre[cç][aã]o/i],
  ["avComOE", /a(?:cuidade)?\.?\s*v(?:isual)?\.?.*oe.*com\s*corre[cç][aã]o/i],
  ["pioOD", /p(?:ress[aã]o)?\s*i(?:ntra)?o(?:cular)?.*od/i],
  ["pioOE", /p(?:ress[aã]o)?\s*i(?:ntra)?o(?:cular)?.*oe/i],
  ["justificativaClinica", /justificativa|hist[oó]ria\s*cl[ií]nica|hda/i],
];

const BLOQUEADOS = /paciente|usu[aá]rio|cns|cpf|telefone|m[aã]e|nascimento|endere[cç]o|senha|operador/i;

function texto(el) {
  if (!el) return "";
  if ("value" in el) return String(el.value || "").trim();
  return String(el.textContent || "").trim();
}

function rotuloDoCampo(el) {
  const partes = [];
  if (el.id) {
    const label = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
    if (label) partes.push(texto(label));
  }
  const ancestral = el.closest("label, td, th, .form-group, .campo, .linha");
  if (ancestral) partes.push(texto(ancestral).slice(0, 240));
  partes.push(el.getAttribute("name") || "", el.id || "", el.getAttribute("aria-label") || "");
  return partes.filter(Boolean).join(" | ");
}

function capturar(incluirNarrativa) {
  const campos = {};
  const bloqueadosDetectados = [];
  const elementos = document.querySelectorAll("input, select, textarea, [data-value]");

  for (const el of elementos) {
    const rotulo = rotuloDoCampo(el);
    const valor = texto(el);
    if (!rotulo || !valor) continue;
    if (BLOQUEADOS.test(rotulo)) {
      bloqueadosDetectados.push(rotulo.slice(0, 80));
      continue;
    }
    for (const [chave, regra] of REGRAS) {
      if (chave === "justificativaClinica" && !incluirNarrativa) continue;
      if (regra.test(rotulo) && !campos[chave]) campos[chave] = valor;
    }
  }

  return {
    origem: "sisreg-extension",
    versao: "0.1.0",
    adaptador: VERSAO_ADAPTADOR,
    capturadoEm: new Date().toISOString(),
    pagina: location.pathname,
    campos,
    metadados: {
      somenteLeitura: true,
      narrativaIncluida: Boolean(incluirNarrativa),
      quantidadeBloqueados: bloqueadosDetectados.length
    }
  };
}

chrome.runtime.onMessage.addListener((mensagem, _sender, responder) => {
  if (mensagem?.tipo !== "ORBITA_CAPTURAR") return;
  responder({ ok: true, pacote: capturar(Boolean(mensagem.incluirNarrativa)) });
});
