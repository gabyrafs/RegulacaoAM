const $ = (id) => document.getElementById(id);
const estado = $("estado");
const saida = $("saida");
const copiar = $("copiar");

$("capturar").addEventListener("click", async () => {
  estado.textContent = "Lendo somente campos permitidos da aba ativa...";
  saida.value = "";
  copiar.disabled = true;
  try {
    const [aba] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!aba?.id || !aba.url?.startsWith("https://sisregiii.saude.gov.br/")) {
      throw new Error("Abra uma tela do SISREG III na aba ativa.");
    }
    const respostas = await chrome.tabs.sendMessage(aba.id, {
      tipo: "ORBITA_CAPTURAR",
      incluirNarrativa: $("narrativa").checked,
    });
    const resposta = Array.isArray(respostas) ? respostas.find((r) => r?.ok) : respostas;
    if (!resposta?.ok) throw new Error("A tela atual não respondeu ao conector.");
    saida.value = JSON.stringify(resposta.pacote, null, 2);
    copiar.disabled = false;
    estado.textContent = `${Object.keys(resposta.pacote.campos || {}).length} campos capturados para revisão.`;
  } catch (e) {
    estado.textContent = e?.message || "Falha na captura.";
  }
});

copiar.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(saida.value);
    estado.textContent = "Pacote copiado. Cole em Integração SISREG no Órbita.";
  } catch {
    saida.select();
    document.execCommand("copy");
    estado.textContent = "Pacote copiado pelo modo de compatibilidade.";
  }
});
